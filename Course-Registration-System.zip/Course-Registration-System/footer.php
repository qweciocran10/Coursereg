<footer>
    <p>&copy; 2023 Course Registration System</p>
</footer>